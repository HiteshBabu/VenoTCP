#define UTS_RELEASE "4.4.0-93-generic"
#define UTS_UBUNTU_RELEASE_ABI 93
