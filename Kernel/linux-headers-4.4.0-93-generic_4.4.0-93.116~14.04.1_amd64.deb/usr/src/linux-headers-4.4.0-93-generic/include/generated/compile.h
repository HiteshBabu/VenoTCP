/* This file is auto generated, version 116~14.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#116~14.04.1 SMP Sun Sep 17 11:28:09 PDT 2017"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "lab6-VirtualBox"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04.3) "
